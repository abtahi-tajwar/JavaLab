class DebitAccount extends Account
{
	private double depositeRange;
	private double accountLimit;
	public DebitAccount()
	{
		depositeRange = 20000;
		accountLimit = 100000;
	}
	public DebitAccount(double amount, double depositeRange, double accountLimit, String name, int id, 
							Date d, String nom)
	{   
		super.name = name;
		super.id = id;
		super.dob = d;
		super.nom = nom;
		this.depositeRange = depositeRange;
		this.accountLimit = accountLimit;
		if(deposite(amount)){
			System.out.println("Successfully Deposited");
		}
		else{
			
			System.out.println("Unable to deposite please check all the criterias");
		}
	}
	
	@Override
	public boolean deposite(double amount)
	{
		if(super.balance > depositeRange){
			return false;
		}
		else{
			if(super.balance + amount > accountLimit)
			{
				return false;
			}
			else{
				super.balance += amount;
				return true;
			}
		}
	}
	
	public boolean withdraw(double amount)
	{
		return super.withdraw(amount);
	}
	public void printAccount()
	{
		super.printAccount();
	}
}