class Savings extends Account
{
	public Savings()
	{
		super.name = "none";
		super.id = 0;
		super.dob = new Date();
		super.nom = "none";
	}
	public Savings(double amount, String name, int id, Date dob,
					String nom)
	{
		super.balance = amount;
		super.name = name;
		super.id = id;
		super.dob = dob;
		super.nom = nom;
	}
	
	@Override
	public boolean deposite(double amount)
	{
		super.balance += amount;
		return true;
	}
	@Override
	public boolean withdraw(double amount)
	{
		super.balance -= amount;
		return true;
	}
	public void printAccount()
	{
		super.printAccount();
	}
}