public class bank                                       /*Main class */
{
    public static void main(String[] args)              /* Main method */
    {
        Date d = new Date(12,11,1999);                                             //Initialized date of birth of the accounts customer
        account a = new account("Md. Abtahi Tajwar", 01, d, "Maksud Ahmed");    //Initialized an account
        a.printAccount();
        if(a.deposite(10000) == true){                     //Checks if the money successfully deposited
            System.out.println("Deposited");
        }
        a.printAccount();                                //Prints the account information
        if(a.withdraw(7000) == true){                      //Checks if the money successfully winthdrawn  
            System.out.println("Withdrawn");
        }
        else{
            System.out.println("Not enough money");
        }
        a.printAccount();
        if(a.withdraw(5000) == true){                       //Checks if the money successfully withdrawn
            System.out.println("Withdrawn");
        }
        else{
            System.out.println("Not enough money");
        }
        a.printAccount();
    }
}
class Date                                                  //Date class defined for taking date as input in a specific format
{
    public int day, month, year;
    public Date()
    {
        day = 01;
        month = 01;
        year = 01;
    }
    public Date(int day, int month, int year)
    {
        this.day = day;
        this.month = month;
        this.year = year;
    }
    public String getDate()                                 //To return date in a specific format
    {
        return this.day+"/"+this.month+"/"+this.year;
    }
    
}
class account
{
    protected String name, nom;                //Name and nominee name of a customer
    protected int id;                           //Id of a customer
    protected Date dob;                         //Date of birth of a customer. Used custom Date class defined on the top of this file
    protected double balance;                   //Total balance of a customer
    public account()
    {

    }
    protected account(String name, int id, Date dob, String nom)    //Permiterized constructor of account class
    {
        this.name = name;
        this.id = id;
        this.dob = dob;
        this.nom = nom;
    }
    protected boolean deposite(double amount)                       //Deposites total money into bank balance
    {
        this.balance += amount;
        System.out.println("Deposited "+amount+"tk");
        return true;
        
    }
    protected boolean withdraw(double amount)                       //Withdraws money from total balance
    {
        if(this.balance > amount)
        {
            this.balance -= amount;
            //System.out.println("Deposited "+amount+"tk");
            return true;
        }
        else{
            return false;
        }
    }
    protected void printAccount()                                   //Prints the complete info of the account of a customer
    {
        System.out.println("ID: "+this.id);
        System.out.println("Name: "+this.name);
        System.out.println("Nomination Name: "+this.nom);
        System.out.println("Current Balance: "+this.balance);
        System.out.println("Date of birth: "+dob.getDate());
    }
}